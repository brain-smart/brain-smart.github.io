#ifndef EEGdef_H
#define EEGdef_H
#define MAXORDER 50
#define MAXTRY 20

#endif

